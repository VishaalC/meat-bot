import os
import discord

client = discord.Client()


@client.event
async def on_ready():
    print("We have logged in as {0.user}".format(client))


@client.event
async def on_message(message):
    if message.author == client.user:
        return
    
    if message.content.startswith("VineMeat"):
        await message.channel.send(file=discord.File('VineMeat.jpg'))
        await message.channel.send(file=discord.File('vinemeat_SVPWuog.mp3'))
    
    if message.content.startswith("HappMeat"):
        await message.channel.send(file=discord.File('Meatav.gif'))
        await message.channel.send(file=discord.File('meat2.mp3'))

    if message.content.startswith("Meat"):
        await message.channel.send(file=discord.File("Meat.webp"))
        await message.channel.send(file=discord.File("meat4.mp3"))
    
    if message.content.startswith("meatFren"):
        await message.channel.send(file=discord.File("95474 - artist ayanathedork meat streamer vinny.png"))
        await message.channel.send(file=discord.File("lolmeatsweats-online-audio-converter.mp3"))
    
    if message.content.startswith("meatPat"):
        await message.channel.send(file=discord.File("MeatPat.gif"))
        await message.channel.send(file=discord.File("meat5.mp3"))
    
    if message.content.startswith("lungimeat"):
        await message.channel.send(file=discord.File("IMG_20210727_103749.jpg"))

client.run(os.environ['TOKEN'])